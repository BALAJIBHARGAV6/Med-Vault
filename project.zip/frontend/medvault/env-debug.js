import { DEPLOYMENT_CONFIG, DEV_MODE } from './src/utils/deployment';

console.log('=== ENVIRONMENT TEST ===');
console.log('Raw env vars:');
console.log('  VITE_MODULE_ADDR:', import.meta.env.VITE_MODULE_ADDR);
console.log('  VITE_DEV_MODE:', import.meta.env.VITE_DEV_MODE);
console.log('  VITE_NETWORK:', import.meta.env.VITE_NETWORK);

console.log('Processed config:');
console.log('  MODULE_ADDRESS:', DEPLOYMENT_CONFIG.MODULE_ADDRESS);
console.log('  DEV_MODE:', DEV_MODE);
console.log('  NETWORK:', DEPLOYMENT_CONFIG.NETWORK);
console.log('========================');
