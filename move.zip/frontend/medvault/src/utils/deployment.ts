// Deployment configuration for MedVault smart contracts
export const DEPLOYMENT_CONFIG = {
  // Using a test address for now - will be updated when contracts are deployed
  MODULE_ADDRESS: '0x1', // Replace with actual deployed address
  NETWORK: 'testnet',
  NODE_URL: 'https://fullnode.testnet.aptoslabs.com/v1',
};

// Set to false for real blockchain interactions
export const DEV_MODE = false;

export const MOCK_RESPONSES = {
  CREATE_ORG: {
    success: true,
    hash: '0x123456789abcdef',
    message: 'Organization created successfully (mock mode)'
  },
  REGISTER_DOCTOR: {
    success: true,
    hash: '0x987654321fedcba',
    message: 'Doctor registered successfully (mock mode)'
  }
};
