import { Web3Storage } from 'web3.storage';

// Initialize Web3.Storage client
const token = import.meta.env.VITE_WEB3_STORAGE_TOKEN;

if (!token) {
  console.warn('VITE_WEB3_STORAGE_TOKEN not set. IPFS functionality will not work.');
}

const client = token ? new Web3Storage({ token }) : null;

/**
 * Upload an encrypted blob to IPFS via Web3.Storage
 */
export async function uploadEncryptedBlob(blob: Blob): Promise<string> {
  if (!client) {
    throw new Error('Web3.Storage not configured. Please set VITE_WEB3_STORAGE_TOKEN');
  }

  try {
    // Create a file from the blob with a unique name
    const timestamp = Date.now();
    const filename = `medvault-record-${timestamp}.encrypted`;
    const file = new File([blob], filename, { type: 'application/octet-stream' });

    // Upload to IPFS
    const cid = await client.put([file], {
      name: filename,
      maxRetries: 3,
    });

    console.log('Successfully uploaded to IPFS:', cid);
    return cid;
  } catch (error) {
    console.error('IPFS upload failed:', error);
    throw new Error(`Failed to upload to IPFS: ${error}`);
  }
}

/**
 * Retrieve a file from IPFS using its CID
 */
export async function getFileFromCid(cid: string): Promise<Blob> {
  try {
    // Try multiple IPFS gateways for better reliability
    const gateways = [
      `https://dweb.link/ipfs/${cid}`,
      `https://ipfs.io/ipfs/${cid}`,
      `https://${cid}.ipfs.w3s.link`,
    ];

    let lastError: Error | null = null;

    for (const gateway of gateways) {
      try {
        console.log('Trying gateway:', gateway);
        const response = await fetch(gateway, {
          method: 'GET',
          headers: {
            'Accept': 'application/octet-stream, */*',
          },
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const blob = await response.blob();
        console.log('Successfully retrieved from IPFS via', gateway);
        return blob;
      } catch (error) {
        console.warn(`Gateway ${gateway} failed:`, error);
        lastError = error as Error;
        continue;
      }
    }

    throw lastError || new Error('All IPFS gateways failed');
  } catch (error) {
    console.error('IPFS retrieval failed:', error);
    throw new Error(`Failed to retrieve from IPFS: ${error}`);
  }
}

/**
 * Upload multiple files to IPFS
 */
export async function uploadFiles(files: File[]): Promise<string> {
  if (!client) {
    throw new Error('Web3.Storage not configured. Please set VITE_WEB3_STORAGE_TOKEN');
  }

  try {
    const cid = await client.put(files, {
      name: `medvault-files-${Date.now()}`,
      maxRetries: 3,
    });

    console.log('Successfully uploaded files to IPFS:', cid);
    return cid;
  } catch (error) {
    console.error('IPFS files upload failed:', error);
    throw new Error(`Failed to upload files to IPFS: ${error}`);
  }
}

/**
 * Get file metadata from IPFS
 */
export async function getFileInfo(cid: string) {
  if (!client) {
    throw new Error('Web3.Storage not configured');
  }

  try {
    const res = await client.get(cid);
    if (!res) {
      throw new Error('File not found');
    }

    const files = await res.files();
    return files.map(file => ({
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream'
    }));
  } catch (error) {
    console.error('Failed to get file info:', error);
    throw error;
  }
}

/**
 * Check if Web3.Storage is properly configured
 */
export function isIPFSConfigured(): boolean {
  return !!client;
}

/**
 * Get IPFS gateway URL for a CID
 */
export function getIPFSUrl(cid: string, filename?: string): string {
  const baseUrl = `https://dweb.link/ipfs/${cid}`;
  return filename ? `${baseUrl}/${filename}` : baseUrl;
}

/**
 * Validate CID format
 */
export function isValidCID(cid: string): boolean {
  // Basic CID validation - should start with 'Qm' (v0) or 'bafy' (v1)
  return /^(Qm[1-9A-HJ-NP-Za-km-z]{44}|bafy[a-z2-7]{56})$/.test(cid);
}
      issuing_org: string;
    }
  ): Promise<string> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please set VITE_WEB3_STORAGE_TOKEN');
    }

    try {
      // Create files for upload
      const encryptedFile = new File([encryptedData], 'encrypted_record.bin', {
        type: 'application/octet-stream'
      });

      const metadataFile = new File([JSON.stringify(metadata, null, 2)], 'metadata.json', {
        type: 'application/json'
      });

      // Upload to IPFS
      const cid = await this.client.put([encryptedFile, metadataFile], {
        name: `medvault_record_${Date.now()}`,
        maxRetries: 3,
      });

      console.log('Uploaded to IPFS with CID:', cid);
      return cid;
    } catch (error) {
      console.error('Failed to upload to IPFS:', error);
      throw new Error(`IPFS upload failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Retrieve encrypted blob from IPFS
  async retrieveEncryptedBlob(cid: string): Promise<{
    encryptedData: Uint8Array;
    metadata: any;
  }> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please set VITE_WEB3_STORAGE_TOKEN');
    }

    try {
      // Retrieve files from IPFS
      const res = await this.client.get(cid);
      if (!res.ok) {
        throw new Error(`Failed to fetch ${cid} - [${res.status}] ${res.statusText}`);
      }

      const files = await res.files();
      
      let encryptedData: Uint8Array | null = null;
      let metadata: any = null;

      for (const file of files) {
        if (file.name === 'encrypted_record.bin') {
          const arrayBuffer = await file.arrayBuffer();
          encryptedData = new Uint8Array(arrayBuffer);
        } else if (file.name === 'metadata.json') {
          const text = await file.text();
          metadata = JSON.parse(text);
        }
      }

      if (!encryptedData) {
        throw new Error('Encrypted record not found in IPFS');
      }

      return {
        encryptedData,
        metadata: metadata || {}
      };
    } catch (error) {
      console.error('Failed to retrieve from IPFS:', error);
      throw new Error(`IPFS retrieval failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Upload file attachments
  async uploadFileAttachments(files: File[]): Promise<string[]> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please set VITE_WEB3_STORAGE_TOKEN');
    }

    const cidPromises = files.map(async (file) => {
      try {
        const cid = await this.client!.put([file], {
          name: `attachment_${file.name}_${Date.now()}`,
          maxRetries: 3,
        });
        return cid;
      } catch (error) {
        console.error(`Failed to upload ${file.name}:`, error);
        throw error;
      }
    });

    return Promise.all(cidPromises);
  }

  // Retrieve file attachment
  async retrieveFileAttachment(cid: string, fileName?: string): Promise<File> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please set VITE_WEB3_STORAGE_TOKEN');
    }

    try {
      const res = await this.client.get(cid);
      if (!res.ok) {
        throw new Error(`Failed to fetch ${cid} - [${res.status}] ${res.statusText}`);
      }

      const files = await res.files();
      if (files.length === 0) {
        throw new Error('No files found in IPFS');
      }

      // Return the first file (or find by name if specified)
      let targetFile = files[0];
      if (fileName) {
        const namedFile = files.find(f => f.name === fileName);
        if (namedFile) {
          targetFile = namedFile;
        }
      }

      return targetFile;
    } catch (error) {
      console.error('Failed to retrieve file attachment:', error);
      throw new Error(`File retrieval failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Get file info without downloading
  async getFileInfo(cid: string): Promise<{
    name: string;
    size: number;
    type: string;
  }[]> {
    if (!this.client) {
      throw new Error('IPFS client not initialized. Please set VITE_WEB3_STORAGE_TOKEN');
    }

    try {
      const res = await this.client.get(cid);
      if (!res.ok) {
        throw new Error(`Failed to fetch ${cid} - [${res.status}] ${res.statusText}`);
      }

      const files = await res.files();
      return files.map(file => ({
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream'
      }));
    } catch (error) {
      console.error('Failed to get file info:', error);
      throw new Error(`File info retrieval failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Check if CID is valid and accessible
  async validateCID(cid: string): Promise<boolean> {
    if (!this.client) {
      return false;
    }

    try {
      const res = await this.client.get(cid);
      return res.ok;
    } catch {
      return false;
    }
  }

  // Get storage status
  async getStorageInfo(): Promise<{
    used: number;
    allocated: number;
  } | null> {
    if (!this.client) {
      return null;
    }

    try {
      // Note: web3.storage doesn't provide direct storage info in the current API
      // This is a placeholder for future implementation
      return {
        used: 0,
        allocated: 0
      };
    } catch (error) {
      console.error('Failed to get storage info:', error);
      return null;
    }
  }

  // Helper to create IPFS gateway URL
  static createGatewayUrl(cid: string, fileName?: string): string {
    const baseUrl = 'https://w3s.link/ipfs';
    return fileName ? `${baseUrl}/${cid}/${fileName}` : `${baseUrl}/${cid}`;
  }

  // Helper to extract CID from various URL formats
  static extractCIDFromUrl(url: string): string | null {
    const cidRegex = /Qm[1-9A-HJ-NP-Za-km-z]{44,}|b[A-Za-z2-7]{58,}|z[1-9A-HJ-NP-Za-km-z]{48,}/;
    const match = url.match(cidRegex);
    return match ? match[0] : null;
  }
}

// Export singleton instance
export const ipfsService = new IPFSService();

// Utility functions
export function cidToBytes(cid: string): Uint8Array {
  return new TextEncoder().encode(cid);
}

export function bytesToCid(bytes: Uint8Array): string {
  return new TextDecoder().decode(bytes);
}

export function cidToArray(cid: string): number[] {
  return Array.from(new TextEncoder().encode(cid));
}

export function arrayToCid(array: number[]): string {
  return new TextDecoder().decode(new Uint8Array(array));
}
