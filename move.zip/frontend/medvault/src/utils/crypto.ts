// Cryptographic utilities for MedVault using libsodium
import sodium from 'libsodium-wrappers';

// Initialize libsodium
let sodiumReady = false;

export async function initializeCrypto(): Promise<void> {
  if (!sodiumReady) {
    await sodium.ready;
    sodiumReady = true;
  }
}

/**
 * Generate AES key for symmetric encryption
 */
export async function generateAesKey(): Promise<Uint8Array> {
  await initializeCrypto();
  return sodium.randombytes_buf(sodium.crypto_secretbox_KEYBYTES);
}

/**
 * Generate key pair for asymmetric encryption
 */
export async function generateKeyPair(): Promise<{ publicKey: Uint8Array; privateKey: Uint8Array }> {
  await initializeCrypto();
  const keyPair = sodium.crypto_box_keypair();
  return {
    publicKey: keyPair.publicKey,
    privateKey: keyPair.privateKey,
  };
}

/**
 * Encrypt blob using AEAD (authenticated encryption)
 */
export async function encryptBlob(aesKey: Uint8Array, arrayBuffer: ArrayBuffer): Promise<{ iv: Uint8Array; cipher: Uint8Array }> {
  await initializeCrypto();
  
  const data = new Uint8Array(arrayBuffer);
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const cipher = sodium.crypto_secretbox_easy(data, nonce, aesKey);
  
  return {
    iv: nonce,
    cipher: cipher
  };
}

/**
 * Decrypt blob using AEAD
 */
export async function decryptBlob(aesKey: Uint8Array, iv: Uint8Array, cipher: Uint8Array): Promise<ArrayBuffer> {
  await initializeCrypto();
  
  const decrypted = sodium.crypto_secretbox_open_easy(cipher, iv, aesKey);
  return decrypted.buffer;
}

/**
 * Wrap AES key for recipient using public key encryption (crypto_box_seal)
 */
export async function wrapKeyForRecipient(aesKey: Uint8Array, recipientPublicKey: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  
  return sodium.crypto_box_seal(aesKey, recipientPublicKey);
}

/**
 * Unwrap AES key using recipient's key pair
 */
export async function unwrapKeyForRecipient(wrappedKey: Uint8Array, recipientKeyPair: { publicKey: Uint8Array; privateKey: Uint8Array }): Promise<Uint8Array> {
  await initializeCrypto();
  
  return sodium.crypto_box_seal_open(wrappedKey, recipientKeyPair.publicKey, recipientKeyPair.privateKey);
}

/**
 * Convert Uint8Array to Array<number> for blockchain
 */
export function uint8ArrayToNumberArray(arr: Uint8Array): number[] {
  return Array.from(arr);
}

/**
 * Convert Array<number> to Uint8Array from blockchain
 */
export function numberArrayToUint8Array(arr: number[]): Uint8Array {
  return new Uint8Array(arr);
}

/**
 * Convert hex string to Uint8Array
 */
export function hexToUint8Array(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
  }
  return bytes;
}

/**
 * Convert Uint8Array to hex string
 */
export function uint8ArrayToHex(arr: Uint8Array): string {
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Store key pair in browser storage (with encryption)
 */
export async function storeKeyPair(keyPair: { publicKey: Uint8Array; privateKey: Uint8Array }, userId: string): Promise<void> {
  const storage = {
    publicKey: uint8ArrayToHex(keyPair.publicKey),
    privateKey: uint8ArrayToHex(keyPair.privateKey),
    createdAt: Date.now()
  };
  
  localStorage.setItem(`medvault_keys_${userId}`, JSON.stringify(storage));
}

/**
 * Retrieve key pair from browser storage
 */
export async function retrieveKeyPair(userId: string): Promise<{ publicKey: Uint8Array; privateKey: Uint8Array } | null> {
  const stored = localStorage.getItem(`medvault_keys_${userId}`);
  if (!stored) return null;
  
  try {
    const storage = JSON.parse(stored);
    return {
      publicKey: hexToUint8Array(storage.publicKey),
      privateKey: hexToUint8Array(storage.privateKey)
    };
  } catch (error) {
    console.error('Failed to retrieve key pair:', error);
    return null;
  }
}

/**
 * Clear stored key pair
 */
export function clearKeyPair(userId: string): void {
  localStorage.removeItem(`medvault_keys_${userId}`);
}

/**
 * Create secure random record ID
 */
export async function generateRecordId(patient: string, doctor: string, timestamp: number): Promise<Uint8Array> {
  await initializeCrypto();
  
  const nonce = sodium.randombytes_buf(16);
  const input = `${patient}|${doctor}|${timestamp}|${uint8ArrayToHex(nonce)}`;
  return sodium.crypto_generichash(32, input);
}
}

// Encrypt data using AES (XChaCha20-Poly1305)
export async function encryptData(data: Uint8Array, key: Uint8Array): Promise<EncryptedRecord> {
  await initializeCrypto();
  
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const encrypted = sodium.crypto_secretbox_easy(data, nonce, key);
  
  return {
    encrypted_data: encrypted,
    nonce: nonce,
    auth_tag: new Uint8Array(), // XChaCha20-Poly1305 includes auth tag in encrypted data
  };
}

// Decrypt data using AES (XChaCha20-Poly1305)
export async function decryptData(encryptedRecord: EncryptedRecord, key: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  
  try {
    const decrypted = sodium.crypto_secretbox_open_easy(
      encryptedRecord.encrypted_data,
      encryptedRecord.nonce,
      key
    );
    return decrypted;
  } catch (error) {
    throw new Error('Failed to decrypt data: Invalid key or corrupted data');
  }
}

// Wrap a symmetric key using public key encryption (sealed box)
export async function wrapKey(symmetricKey: Uint8Array, recipientPublicKey: Uint8Array): Promise<WrappedKey> {
  await initializeCrypto();
  
  const wrappedKey = sodium.crypto_box_seal(symmetricKey, recipientPublicKey);
  
  return {
    wrapped_key: wrappedKey,
    recipient_public_key: recipientPublicKey,
  };
}

// Unwrap a symmetric key using private key
export async function unwrapKey(wrappedKey: WrappedKey, recipientPrivateKey: Uint8Array, recipientPublicKey: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  
  try {
    const symmetricKey = sodium.crypto_box_seal_open(
      wrappedKey.wrapped_key,
      recipientPublicKey,
      recipientPrivateKey
    );
    return symmetricKey;
  } catch (error) {
    throw new Error('Failed to unwrap key: Invalid private key or corrupted wrapped key');
  }
}

// Serialize medical record to bytes
export function serializeMedicalRecord(record: MedicalRecord): Uint8Array {
  const recordString = JSON.stringify(record);
  return new TextEncoder().encode(recordString);
}

// Deserialize medical record from bytes
export function deserializeMedicalRecord(data: Uint8Array): MedicalRecord {
  const recordString = new TextDecoder().decode(data);
  return JSON.parse(recordString) as MedicalRecord;
}

// Create encrypted medical record
export async function createEncryptedMedicalRecord(
  record: MedicalRecord,
  patientPublicKey: Uint8Array
): Promise<{
  encryptedRecord: EncryptedRecord;
  wrappedKeyForPatient: WrappedKey;
  symmetricKey: Uint8Array;
}> {
  await initializeCrypto();
  
  // Serialize the medical record
  const recordData = serializeMedicalRecord(record);
  
  // Generate symmetric key
  const symmetricKey = await generateSymmetricKey();
  
  // Encrypt the record
  const encryptedRecord = await encryptData(recordData, symmetricKey);
  
  // Wrap the symmetric key for the patient
  const wrappedKeyForPatient = await wrapKey(symmetricKey, patientPublicKey);
  
  return {
    encryptedRecord,
    wrappedKeyForPatient,
    symmetricKey,
  };
}

// Decrypt medical record for patient
export async function decryptMedicalRecordForPatient(
  encryptedRecord: EncryptedRecord,
  wrappedKey: WrappedKey,
  patientPrivateKey: Uint8Array,
  patientPublicKey: Uint8Array
): Promise<MedicalRecord> {
  await initializeCrypto();
  
  // Unwrap the symmetric key
  const symmetricKey = await unwrapKey(wrappedKey, patientPrivateKey, patientPublicKey);
  
  // Decrypt the record
  const decryptedData = await decryptData(encryptedRecord, symmetricKey);
  
  // Deserialize the medical record
  return deserializeMedicalRecord(decryptedData);
}

// Grant access by creating wrapped key for another user
export async function grantAccessToRecord(
  symmetricKey: Uint8Array,
  granteePublicKey: Uint8Array
): Promise<WrappedKey> {
  await initializeCrypto();
  return await wrapKey(symmetricKey, granteePublicKey);
}

// Decrypt medical record for granted user
export async function decryptMedicalRecordForGrantee(
  encryptedRecord: EncryptedRecord,
  wrappedKey: WrappedKey,
  granteePrivateKey: Uint8Array,
  granteePublicKey: Uint8Array
): Promise<MedicalRecord> {
  await initializeCrypto();
  
  // Unwrap the symmetric key
  const symmetricKey = await unwrapKey(wrappedKey, granteePrivateKey, granteePublicKey);
  
  // Decrypt the record
  const decryptedData = await decryptData(encryptedRecord, symmetricKey);
  
  // Deserialize the medical record
  return deserializeMedicalRecord(decryptedData);
}

// Utility to convert Uint8Array to hex string
export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Utility to convert hex string to Uint8Array
export function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
  }
  return bytes;
}

// Generate secure random bytes
export async function generateRandomBytes(length: number): Promise<Uint8Array> {
  await initializeCrypto();
  return sodium.randombytes_buf(length);
}

// Hash function for creating record IDs
export async function hashData(data: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  return sodium.crypto_hash_sha256(data);
}

// Create deterministic record ID
export async function createRecordId(
  patientAddr: string,
  doctorAddr: string,
  timestamp: number,
  nonce: Uint8Array
): Promise<Uint8Array> {
  await initializeCrypto();
  
  const data = new TextEncoder().encode(`${patientAddr}|${doctorAddr}|${timestamp}`);
  const combined = new Uint8Array(data.length + nonce.length);
  combined.set(data);
  combined.set(nonce, data.length);
  
  return await hashData(combined);
}

// Key storage helpers for browser
export interface StoredKeyPair {
  publicKey: string;
  privateKey: string;
  address: string;
  timestamp: number;
}

// Store key pair in browser storage (with user consent)
export function storeKeyPair(keyPair: { publicKey: Uint8Array; privateKey: Uint8Array }, address: string): void {
  const stored: StoredKeyPair = {
    publicKey: bytesToHex(keyPair.publicKey),
    privateKey: bytesToHex(keyPair.privateKey),
    address,
    timestamp: Date.now(),
  };
  
  // Store in sessionStorage for security (cleared when browser closes)
  sessionStorage.setItem(`medvault_keys_${address}`, JSON.stringify(stored));
}

// Retrieve key pair from browser storage
export function retrieveKeyPair(address: string): { publicKey: Uint8Array; privateKey: Uint8Array } | null {
  const stored = sessionStorage.getItem(`medvault_keys_${address}`);
  if (!stored) return null;
  
  try {
    const parsed: StoredKeyPair = JSON.parse(stored);
    return {
      publicKey: hexToBytes(parsed.publicKey),
      privateKey: hexToBytes(parsed.privateKey),
    };
  } catch (error) {
    console.error('Failed to parse stored key pair:', error);
    return null;
  }
}

// Clear stored key pair
export function clearStoredKeyPair(address: string): void {
  sessionStorage.removeItem(`medvault_keys_${address}`);
}

// Check if key pair exists for address
export function hasStoredKeyPair(address: string): boolean {
  return sessionStorage.getItem(`medvault_keys_${address}`) !== null;
}

// File encryption utilities
export async function encryptFile(file: File, key: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  
  const fileBuffer = await file.arrayBuffer();
  const fileData = new Uint8Array(fileBuffer);
  
  const nonce = sodium.randombytes_buf(sodium.crypto_secretbox_NONCEBYTES);
  const encrypted = sodium.crypto_secretbox_easy(fileData, nonce, key);
  
  // Combine nonce and encrypted data
  const combined = new Uint8Array(nonce.length + encrypted.length);
  combined.set(nonce);
  combined.set(encrypted, nonce.length);
  
  return combined;
}

export async function decryptFile(encryptedData: Uint8Array, key: Uint8Array): Promise<Uint8Array> {
  await initializeCrypto();
  
  // Extract nonce and encrypted data
  const nonce = encryptedData.slice(0, sodium.crypto_secretbox_NONCEBYTES);
  const encrypted = encryptedData.slice(sodium.crypto_secretbox_NONCEBYTES);
  
  try {
    return sodium.crypto_secretbox_open_easy(encrypted, nonce, key);
  } catch (error) {
    throw new Error('Failed to decrypt file: Invalid key or corrupted data');
  }
}
