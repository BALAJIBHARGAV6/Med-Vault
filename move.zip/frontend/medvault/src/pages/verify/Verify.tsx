import React, { useState } from 'react';
import { verifyRecord } from '../../utils/petra-simple';

const Verify: React.FC = () => {
  const [recordId, setRecordId] = useState('');
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    if (!recordId.trim()) {
      setError('Please enter a record ID');
      return;
    }

    try {
      setIsVerifying(true);
      setError(null);
      setVerificationResult(null);

      const result = await verifyRecord(recordId.trim());
      setVerificationResult(result);
    } catch (err: any) {
      setError(err.message || 'Failed to verify record');
      setVerificationResult(null);
    } finally {
      setIsVerifying(false);
    }
  };

  const resetForm = () => {
    setRecordId('');
    setVerificationResult(null);
    setError(null);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '24px', color: '#1890ff' }}>
        🔍 Record Verification
      </h1>
      <p style={{ marginBottom: '30px', color: '#666' }}>
        Verify the authenticity and integrity of medical records stored on the Aptos blockchain and IPFS.
      </p>

      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        {/* Verification Form */}
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
          <h3 style={{ margin: '0 0 15px 0', color: '#333' }}>🎫 Verify Medical Record</h3>
          <p style={{ color: '#666', marginBottom: '20px' }}>
            Enter the record ID to verify its authenticity on the blockchain
          </p>
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
              Record ID:
            </label>
            <input
              type="text"
              value={recordId}
              onChange={(e) => setRecordId(e.target.value)}
              placeholder="record_1234567890_abcdef123"
              disabled={isVerifying}
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #d9d9d9',
                borderRadius: '4px',
                fontSize: '14px',
                fontFamily: 'monospace',
                backgroundColor: isVerifying ? '#f5f5f5' : 'white'
              }}
            />
          </div>

          {error && (
            <div style={{
              padding: '12px',
              backgroundColor: '#fff2f0',
              border: '1px solid #ffccc7',
              borderRadius: '4px',
              color: '#ff4d4f',
              marginBottom: '15px'
            }}>
              ❌ {error}
            </div>
          )}

          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={handleVerify}
              disabled={isVerifying || !recordId.trim()}
              style={{
                flex: 1,
                padding: '12px 20px',
                backgroundColor: isVerifying || !recordId.trim() ? '#d9d9d9' : '#1890ff',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: isVerifying || !recordId.trim() ? 'not-allowed' : 'pointer',
                fontSize: '16px',
                fontWeight: 'bold'
              }}
            >
              {isVerifying ? '🔄 Verifying...' : '🔍 Verify Record'}
            </button>
            <button
              onClick={resetForm}
              disabled={isVerifying}
              style={{
                padding: '12px 20px',
                backgroundColor: '#666',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: isVerifying ? 'not-allowed' : 'pointer'
              }}
            >
              Clear
            </button>
          </div>
        </div>

        {/* Verification Results */}
        {verificationResult && (
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '20px' }}>
              <span style={{ fontSize: '24px', marginRight: '10px' }}>
                {verificationResult.isValid ? '✅' : '❌'}
              </span>
              <h3 style={{ margin: 0, color: verificationResult.isValid ? '#52c41a' : '#ff4d4f' }}>
                {verificationResult.isValid ? 'Record Verified' : 'Verification Failed'}
              </h3>
            </div>

            {verificationResult.isValid && verificationResult.record && (
              <div>
                <div style={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f6ffed', borderRadius: '6px', border: '1px solid #b7eb8f' }}>
                  <h4 style={{ margin: '0 0 10px 0', color: '#52c41a' }}>📋 Record Details</h4>
                  <div style={{ display: 'grid', gap: '8px', fontSize: '14px' }}>
                    <div><strong>Title:</strong> {verificationResult.record.title}</div>
                    <div><strong>Type:</strong> {verificationResult.record.recordType}</div>
                    <div><strong>Patient:</strong> {verificationResult.record.patientAddress}</div>
                    <div><strong>Doctor:</strong> {verificationResult.record.doctorAddress}</div>
                    <div><strong>Created:</strong> {new Date(verificationResult.record.createdAt).toLocaleString()}</div>
                  </div>
                </div>

                <div style={{ marginBottom: '20px', padding: '15px', backgroundColor: '#f0f8ff', borderRadius: '6px', border: '1px solid #91d5ff' }}>
                  <h4 style={{ margin: '0 0 10px 0', color: '#1890ff' }}>🔐 Security Details</h4>
                  <div style={{ display: 'grid', gap: '8px', fontSize: '14px' }}>
                    <div><strong>Blockchain:</strong> {verificationResult.verificationDetails.onChain ? '✅ On-chain' : '❌ Not on-chain'}</div>
                    <div><strong>Encryption:</strong> {verificationResult.verificationDetails.encrypted ? '✅ Encrypted' : '❌ Not encrypted'}</div>
                    <div><strong>IPFS Storage:</strong> {verificationResult.verificationDetails.ipfsStored ? '✅ Stored on IPFS' : '❌ Not on IPFS'}</div>
                    <div><strong>Transaction Hash:</strong> {verificationResult.verificationDetails.transactionHash || 'N/A'}</div>
                  </div>
                </div>

                <div style={{ padding: '15px', backgroundColor: '#fff7e6', borderRadius: '6px', border: '1px solid #ffd591' }}>
                  <h4 style={{ margin: '0 0 10px 0', color: '#fa8c16' }}>📝 Description</h4>
                  <p style={{ margin: 0, fontSize: '14px', lineHeight: '1.5' }}>
                    {verificationResult.record.description}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Info Section */}
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginTop: '20px' }}>
          <h4 style={{ margin: '0 0 15px 0', color: '#333' }}>ℹ️ How Verification Works</h4>
          <ul style={{ color: '#666', fontSize: '14px', lineHeight: '1.6' }}>
            <li>Each medical record is assigned a unique ID when created</li>
            <li>Records are stored on the Aptos blockchain for immutable verification</li>
            <li>File attachments are encrypted and stored on IPFS</li>
            <li>Only authorized parties (patient and doctor) can access full record details</li>
            <li>Verification checks blockchain authenticity and data integrity</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Verify;
