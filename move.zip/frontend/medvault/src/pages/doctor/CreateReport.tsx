import React, { useState, useEffect } from 'react';
import { createMedicalRecord } from '../../utils/petra-simple';
import { generateEncryptionKey, encryptFile, simulateIPFSUpload } from '../../utils/crypto-simple';

const CreateReport: React.FC = () => {
  const [formData, setFormData] = useState({
    patientAddress: '',
    recordType: 'consultation',
    title: '',
    description: '',
    file: null as File | null
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [submitMessage, setSubmitMessage] = useState('');

  // Check for patient parameter in URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const patientParam = urlParams.get('patient');
    if (patientParam) {
      setFormData(prev => ({
        ...prev,
        patientAddress: patientParam
      }));
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear status when user makes changes
    if (submitStatus !== 'idle') {
      setSubmitStatus('idle');
      setSubmitMessage('');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({
      ...prev,
      file
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setSubmitMessage('');

    try {
      // Validate patient address format
      if (!formData.patientAddress.startsWith('0x') || formData.patientAddress.length < 10) {
        throw new Error('Please enter a valid wallet address (0x...)');
      }

      let ipfsHash = '';
      let encryptionKey = '';

      // Handle file encryption and IPFS upload if file is provided
      if (formData.file) {
        setSubmitMessage('Encrypting and uploading medical files...');
        
        // Generate encryption key
        encryptionKey = generateEncryptionKey();
        
        // Encrypt file
        const { encryptedData } = await encryptFile(formData.file, encryptionKey);
        
        // Upload to IPFS (simulated)
        ipfsHash = await simulateIPFSUpload(encryptedData);
        
        setSubmitMessage('Files uploaded securely to IPFS...');
      }

      setSubmitMessage('Creating medical record on blockchain...');

      // Create medical record on blockchain
      const recordId = await createMedicalRecord({
        patientAddress: formData.patientAddress,
        recordType: formData.recordType,
        title: formData.title,
        description: formData.description,
        ipfsHash,
        encryptionKey
      });

      setSubmitStatus('success');
      setSubmitMessage(`Medical record created successfully! Record ID: ${recordId}`);
      
      // Reset form
      setFormData({
        patientAddress: '',
        recordType: 'consultation',
        title: '',
        description: '',
        file: null
      });

      // Reset file input
      const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
      }

    } catch (error: any) {
      setSubmitStatus('error');
      setSubmitMessage(error.message || 'Failed to create medical record');
      console.error('Error creating medical record:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px' }}>
      <h2>📝 Create Medical Record</h2>
      <p style={{ color: '#666', marginBottom: '30px' }}>
        Medical records are encrypted and stored securely on IPFS. Only you control who can access them.
      </p>

      <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '20px' }}>
        <div>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Patient Wallet Address *
          </label>
          <input
            type="text"
            name="patientAddress"
            value={formData.patientAddress}
            onChange={handleInputChange}
            placeholder="0x123...abc"
            required
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              backgroundColor: isSubmitting ? '#f5f5f5' : 'white'
            }}
          />
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Record Type *
          </label>
          <select
            name="recordType"
            value={formData.recordType}
            onChange={handleInputChange}
            required
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              backgroundColor: isSubmitting ? '#f5f5f5' : 'white'
            }}
          >
            <option value="consultation">Consultation Report</option>
            <option value="lab">Lab Results</option>
            <option value="imaging">Imaging Report</option>
            <option value="prescription">Prescription</option>
            <option value="surgery">Surgery Report</option>
            <option value="diagnosis">Diagnosis</option>
          </select>
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Record Title *
          </label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            placeholder="e.g., Annual Checkup Report"
            required
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              backgroundColor: isSubmitting ? '#f5f5f5' : 'white'
            }}
          />
        </div>
              borderRadius: '4px'
        <div>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Medical Report Description *
          </label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Detailed medical findings, recommendations, and notes..."
            required
            rows={6}
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              resize: 'vertical',
              backgroundColor: isSubmitting ? '#f5f5f5' : 'white'
            }}
          />
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
            Attach Medical Files (Optional)
          </label>
          <input
            type="file"
            onChange={handleFileChange}
            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
            disabled={isSubmitting}
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              backgroundColor: isSubmitting ? '#f5f5f5' : 'white'
            }}
          />
          <p style={{ fontSize: '12px', color: '#666', marginTop: '5px' }}>
            Supported formats: PDF, Images, Word documents. Files will be encrypted before upload.
          </p>
        </div>

        {/* Status Message */}
        {(submitMessage || submitStatus !== 'idle') && (
          <div style={{
            padding: '15px',
            borderRadius: '6px',
            backgroundColor: submitStatus === 'success' ? '#f6ffed' : 
                            submitStatus === 'error' ? '#fff2f0' : '#e6f7ff',
            border: `1px solid ${submitStatus === 'success' ? '#b7eb8f' : 
                                 submitStatus === 'error' ? '#ffccc7' : '#91d5ff'}`,
            color: submitStatus === 'success' ? '#52c41a' : 
                   submitStatus === 'error' ? '#ff4d4f' : '#1890ff'
          }}>
            {submitMessage}
          </div>
        )}

        <div style={{ display: 'flex', gap: '15px', marginTop: '20px' }}>
          <button
            type="submit"
            disabled={isSubmitting}
            style={{
              padding: '12px 30px',
              backgroundColor: isSubmitting ? '#d9d9d9' : '#52c41a',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: isSubmitting ? 'not-allowed' : 'pointer',
              fontSize: '16px',
              fontWeight: 'bold'
            }}
          >
            {isSubmitting ? '🔄 Creating...' : '🔐 Create Encrypted Record'}
          </button>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => {
              setFormData({
                patientAddress: '',
                recordType: 'consultation',
                title: '',
                description: '',
                file: null
              });
              setSubmitStatus('idle');
              setSubmitMessage('');
              const fileInput = document.querySelector('input[type="file"]') as HTMLInputElement;
              if (fileInput) fileInput.value = '';
            }}
            style={{
              padding: '12px 30px',
              backgroundColor: isSubmitting ? '#f5f5f5' : '#666',
              color: isSubmitting ? '#999' : 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: isSubmitting ? 'not-allowed' : 'pointer'
            }}
          >
            Clear Form
          </button>
        </div>
      </form>

      <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#f0f8ff', borderRadius: '8px' }}>
        <h4>🔒 Privacy & Security</h4>
        <ul style={{ color: '#666', fontSize: '14px' }}>
          <li>All records are encrypted client-side using AES-256-GCM</li>
          <li>Files are stored on decentralized IPFS network</li>
          <li>Only the patient can grant access to other doctors</li>
          <li>Soulbound NFT minted as proof of authenticity</li>
          <li>All actions are recorded on Aptos blockchain</li>
        </ul>
      </div>
    </div>
  );
};

export default CreateReport;
