import React, { useState, useEffect } from 'react';
import { getPatientRecords, grantRecordAccess } from '../../utils/petra-simple';

const PatientDashboard: React.FC = () => {
  const [records, setRecords] = useState<any[]>([]);
  const [patientAddress, setPatientAddress] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAccessModal, setShowAccessModal] = useState(false);
  const [selectedRecordId, setSelectedRecordId] = useState<string>('');
  const [doctorAddress, setDoctorAddress] = useState('');
  const [grantingAccess, setGrantingAccess] = useState(false);

  useEffect(() => {
    loadPatientData();
  }, []);

  const loadPatientData = async () => {
    try {
      setLoading(true);
      
      // Get patient address from Petra
      if (window.aptos) {
        const account = await window.aptos.account();
        setPatientAddress(account.address);
        
        // Load patient's medical records
        const patientRecords = await getPatientRecords(account.address);
        setRecords(patientRecords);
      }
      
    } catch (error) {
      console.error('Failed to load patient data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGrantAccess = async () => {
    if (!selectedRecordId || !doctorAddress.trim()) {
      alert('Please enter a valid doctor address');
      return;
    }

    setGrantingAccess(true);
    try {
      const success = await grantRecordAccess(selectedRecordId, doctorAddress.trim());
      if (success) {
        alert('Access granted successfully!');
        setShowAccessModal(false);
        setDoctorAddress('');
        setSelectedRecordId('');
        // Reload records to show updated access
        await loadPatientData();
      } else {
        throw new Error('Failed to grant access');
      }
    } catch (error: any) {
      alert('Error granting access: ' + error.message);
    } finally {
      setGrantingAccess(false);
    }
  };

  const navigateToRecord = (recordId: string) => {
    window.location.href = `/patient/record/${recordId}`;
  };

  const navigateToVerify = () => {
    window.location.href = '/verify';
  };

  const openAccessModal = (recordId: string) => {
    setSelectedRecordId(recordId);
    setShowAccessModal(true);
  };

  // Count unique doctors with access
  const uniqueDoctors = new Set(records.map(record => record.doctorAddress)).size;
  
  // Count recent records (last 30 days)
  const recentRecords = records.filter(record => {
    const recordDate = new Date(record.createdAt);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return recordDate > thirtyDaysAgo;
  }).length;

  // Group records by type
  const recordsByType = records.reduce((acc, record) => {
    acc[record.recordType] = (acc[record.recordType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (loading) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <div style={{ fontSize: '18px', color: '#666' }}>Loading your medical records...</div>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', marginBottom: '10px', color: '#1890ff' }}>
          🧑‍💼 Patient Dashboard
        </h1>
        <p style={{ color: '#666', fontSize: '16px' }}>
          Welcome to your personal health record dashboard. View and manage your medical records securely.
        </p>
        {patientAddress && (
          <div style={{ 
            marginTop: '15px', 
            padding: '10px 15px', 
            backgroundColor: '#f0f8ff', 
            borderRadius: '6px', 
            border: '1px solid #bfdbfe' 
          }}>
            <strong>Your Wallet Address:</strong>
            <div style={{ 
              fontFamily: 'monospace', 
              fontSize: '14px', 
              color: '#1e40af', 
              marginTop: '5px',
              wordBreak: 'break-all'
            }}>
              {patientAddress}
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText(patientAddress);
                alert('Wallet address copied to clipboard!');
              }}
              style={{
                marginTop: '8px',
                padding: '4px 8px',
                backgroundColor: '#1890ff',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                fontSize: '12px',
                cursor: 'pointer'
              }}
            >
              📋 Copy Address
            </button>
          </div>
        )}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px', marginBottom: '30px' }}>
        <div style={{ padding: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <h3 style={{ margin: '0 0 15px 0', color: '#333' }}>📋 My Records</h3>
          <p style={{ color: '#666', marginBottom: '15px' }}>
            {records.length} medical records available
          </p>
          <button 
            onClick={() => window.location.href = '#records-section'}
            style={{ 
              display: 'inline-block', 
              padding: '10px 20px', 
              backgroundColor: '#1890ff', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            View All Records
          </button>
        </div>

        <div style={{ padding: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <h3 style={{ margin: '0 0 15px 0', color: '#333' }}>🔐 Access Control</h3>
          <p style={{ color: '#666', marginBottom: '15px' }}>
            Manage doctor access to your records
          </p>
          <button 
            onClick={() => window.location.href = '#access-control-section'}
            style={{ 
              display: 'inline-block', 
              padding: '10px 20px', 
              backgroundColor: '#52c41a', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Manage Access
          </button>
        </div>

        <div style={{ padding: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
          <h3 style={{ margin: '0 0 15px 0', color: '#333' }}>🔍 Verify Records</h3>
          <p style={{ color: '#666', marginBottom: '15px' }}>Verify authenticity of medical certificates</p>
          <button 
            onClick={navigateToVerify}
            style={{ 
              display: 'inline-block', 
              padding: '10px 20px', 
              backgroundColor: '#722ed1', 
              color: 'white', 
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Verify Now
          </button>
        </div>
      </div>

      {/* Record Types Overview */}
      <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
        <h3 style={{ margin: '0 0 20px 0', color: '#333' }}>📊 Health Overview</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '15px' }}>
          <div style={{ textAlign: 'center', padding: '15px', backgroundColor: '#f0f8ff', borderRadius: '6px' }}>
            <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#1890ff' }}>{records.length}</div>
            <div style={{ color: '#666', fontSize: '14px' }}>Total Records</div>
          </div>
          <div style={{ textAlign: 'center', padding: '15px', backgroundColor: '#f6ffed', borderRadius: '6px' }}>
            <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#52c41a' }}>{uniqueDoctors}</div>
            <div style={{ color: '#666', fontSize: '14px' }}>Authorized Doctors</div>
          </div>
          <div style={{ textAlign: 'center', padding: '15px', backgroundColor: '#fff7e6', borderRadius: '6px' }}>
            <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#fa8c16' }}>{recentRecords}</div>
            <div style={{ color: '#666', fontSize: '14px' }}>Recent Records</div>
          </div>
          <div style={{ textAlign: 'center', padding: '15px', backgroundColor: '#f9f0ff', borderRadius: '6px' }}>
            <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#722ed1' }}>100%</div>
            <div style={{ color: '#666', fontSize: '14px' }}>Encrypted</div>
          </div>
        </div>

        {/* Record Types Breakdown */}
        {Object.keys(recordsByType).length > 0 && (
          <div style={{ marginTop: '20px' }}>
            <h4 style={{ marginBottom: '15px', color: '#333' }}>📋 Records by Type</h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '10px' }}>
              {Object.entries(recordsByType).map(([type, count]) => (
                <div
                  key={type}
                  style={{
                    padding: '10px',
                    backgroundColor: '#f8f9fa',
                    borderRadius: '4px',
                    textAlign: 'center',
                    border: '1px solid #e9ecef'
                  }}
                >
                  <div style={{ fontWeight: 'bold', color: '#495057' }}>{count as number}</div>
                  <div style={{ fontSize: '12px', color: '#6c757d' }}>{type}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Access Control Section */}
      <div id="access-control-section" style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
        <h3 style={{ margin: '0 0 20px 0', color: '#333' }}>🔐 Access Control Management</h3>
        
        {records.length > 0 ? (
          <div>
            <p style={{ color: '#666', marginBottom: '20px' }}>
              Grant access to doctors for specific medical records. Only authorized doctors can view your encrypted data.
            </p>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '15px' }}>
              {records.map((record, index) => (
                <div
                  key={index}
                  style={{
                    padding: '15px',
                    border: '1px solid #d9d9d9',
                    borderRadius: '6px',
                    backgroundColor: '#fafafa'
                  }}
                >
                  <div style={{ fontWeight: 'bold', color: '#333', marginBottom: '5px' }}>
                    {record.title}
                  </div>
                  <div style={{ fontSize: '12px', color: '#999', marginBottom: '10px' }}>
                    {record.recordType} • {new Date(record.createdAt).toLocaleDateString()}
                  </div>
                  <div style={{ fontSize: '12px', color: '#666', marginBottom: '10px' }}>
                    Access granted to: {record.accessList ? record.accessList.length : 1} address(es)
                  </div>
                  <button
                    onClick={() => openAccessModal(record.id)}
                    style={{
                      padding: '6px 12px',
                      backgroundColor: '#52c41a',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      fontSize: '12px',
                      cursor: 'pointer'
                    }}
                  >
                    Grant Access
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p style={{ color: '#666', textAlign: 'center', padding: '20px' }}>
            No records available to manage access for.
          </p>
        )}
      </div>

      {/* Records Section */}
      <div id="records-section">
        {/* Recent Records */}
        {records.length > 0 && (
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginBottom: '20px' }}>
            <h3 style={{ margin: '0 0 20px 0', color: '#333' }}>📋 Your Medical Records</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
              {records.slice(0, 10).map((record, index) => (
                <div
                  key={index}
                  style={{
                    padding: '15px',
                    border: '1px solid #d9d9d9',
                    borderRadius: '6px',
                    backgroundColor: '#fafafa'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                    <div>
                      <div style={{ fontWeight: 'bold', color: '#333' }}>{record.title}</div>
                      <div style={{ fontSize: '12px', color: '#999', textTransform: 'uppercase' }}>
                        {record.recordType}
                      </div>
                    </div>
                    <div style={{ fontSize: '12px', color: '#666' }}>
                      {new Date(record.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  
                  <div style={{ marginBottom: '10px', color: '#666', fontSize: '14px' }}>
                    Doctor: {record.doctorAddress.substring(0, 10)}...{record.doctorAddress.substring(record.doctorAddress.length - 8)}
                  </div>
                  
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
                    {record.ipfsHash && (
                      <span style={{ 
                        fontSize: '12px', 
                        backgroundColor: '#e6f7ff', 
                        color: '#1890ff', 
                        padding: '2px 8px', 
                        borderRadius: '4px' 
                      }}>
                        📎 IPFS Stored
                      </span>
                    )}
                    {record.encryptionKey && (
                      <span style={{ 
                        fontSize: '12px', 
                        backgroundColor: '#f6ffed', 
                        color: '#52c41a', 
                        padding: '2px 8px', 
                        borderRadius: '4px' 
                      }}>
                        🔐 Encrypted
                      </span>
                    )}
                    <button
                      onClick={() => navigateToRecord(record.id)}
                      style={{ 
                        fontSize: '12px', 
                        backgroundColor: '#722ed1', 
                        color: 'white', 
                        padding: '4px 8px', 
                        borderRadius: '4px',
                        border: 'none',
                        cursor: 'pointer'
                      }}
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => openAccessModal(record.id)}
                      style={{ 
                        fontSize: '12px', 
                        backgroundColor: '#52c41a', 
                        color: 'white', 
                        padding: '4px 8px', 
                        borderRadius: '4px',
                        border: 'none',
                        cursor: 'pointer'
                      }}
                    >
                      Grant Access
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {records.length === 0 && (
          <div style={{ backgroundColor: 'white', padding: '40px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', textAlign: 'center' }}>
            <div style={{ fontSize: '48px', marginBottom: '15px' }}>📋</div>
            <h3 style={{ color: '#333', marginBottom: '10px' }}>No Medical Records Yet</h3>
            <p style={{ color: '#666', marginBottom: '20px' }}>
              Your medical records will appear here when doctors create them for you.
            </p>
            <p style={{ color: '#999', fontSize: '14px' }}>
              Share your wallet address with your doctor to get started.
            </p>
          </div>
        )}
      </div>

      {/* Access Modal */}
      {showAccessModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '30px',
            borderRadius: '8px',
            maxWidth: '500px',
            width: '90%'
          }}>
            <h3 style={{ margin: '0 0 20px 0', color: '#333' }}>Grant Doctor Access</h3>
            <p style={{ color: '#666', marginBottom: '20px' }}>
              Enter the doctor's wallet address to grant them access to this medical record.
            </p>
            
            <input
              type="text"
              value={doctorAddress}
              onChange={(e) => setDoctorAddress(e.target.value)}
              placeholder="Enter doctor's wallet address (0x...)"
              disabled={grantingAccess}
              style={{
                width: '100%',
                padding: '12px',
                border: '1px solid #d9d9d9',
                borderRadius: '4px',
                fontFamily: 'monospace',
                fontSize: '14px',
                marginBottom: '20px'
              }}
            />
            
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
              <button
                onClick={() => {
                  setShowAccessModal(false);
                  setDoctorAddress('');
                  setSelectedRecordId('');
                }}
                disabled={grantingAccess}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#f5f5f5',
                  color: '#333',
                  border: '1px solid #d9d9d9',
                  borderRadius: '4px',
                  cursor: grantingAccess ? 'not-allowed' : 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleGrantAccess}
                disabled={grantingAccess || !doctorAddress.trim()}
                style={{
                  padding: '10px 20px',
                  backgroundColor: grantingAccess || !doctorAddress.trim() ? '#d9d9d9' : '#1890ff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: grantingAccess || !doctorAddress.trim() ? 'not-allowed' : 'pointer'
                }}
              >
                {grantingAccess ? 'Granting Access...' : 'Grant Access'}
              </button>
            </div>
            
            <p style={{ fontSize: '12px', color: '#666', margin: '15px 0 0 0' }}>
              ⚠️ Only grant access to trusted medical professionals. This action is recorded on the blockchain.
            </p>
          </div>
        </div>
      )}

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f0f9ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
        <h4 style={{ margin: '0 0 10px 0', color: '#1e40af' }}>💡 Quick Tip</h4>
        <p style={{ margin: 0, color: '#1e40af' }}>
          Your medical records are encrypted and stored securely on IPFS. Only you control who can access them.
        </p>
      </div>
    </div>
  );
};

export default PatientDashboard;
