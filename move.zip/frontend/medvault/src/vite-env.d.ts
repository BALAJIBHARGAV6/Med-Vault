// Environment configuration for Vite
interface ImportMetaEnv {
  readonly VITE_MODULE_ADDR: string;
  readonly VITE_NODE_URL: string;
  readonly VITE_WEB3_STORAGE_TOKEN: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
